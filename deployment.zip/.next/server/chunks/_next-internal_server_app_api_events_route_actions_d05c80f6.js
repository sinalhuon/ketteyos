module.exports=[58731,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_events_route_actions_d05c80f6.js.map