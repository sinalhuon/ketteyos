module.exports=[99838,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_templates_%5Bid%5D_edit_page_actions_ea11194a.js.map