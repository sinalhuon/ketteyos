module.exports=[90678,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_invitation_%5Bslug%5D_page_actions_88a95e8e.js.map