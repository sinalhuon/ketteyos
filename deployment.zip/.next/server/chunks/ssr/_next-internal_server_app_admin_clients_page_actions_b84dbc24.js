module.exports=[38606,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_clients_page_actions_b84dbc24.js.map