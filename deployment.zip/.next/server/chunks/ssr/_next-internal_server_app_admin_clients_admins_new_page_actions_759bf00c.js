module.exports=[340,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_clients_admins_new_page_actions_759bf00c.js.map