module.exports=[4225,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_users_%5Bid%5D_edit_page_actions_0a428eb2.js.map