module.exports=[82263,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_users_new_page_actions_74bdde79.js.map