module.exports=[80069,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_invite_%5B___inviteIds%5D_page_actions_e81b7ec3.js.map