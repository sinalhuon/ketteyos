module.exports=[93137,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_forgot-password_page_actions_fcf18925.js.map