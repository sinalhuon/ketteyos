module.exports=[21194,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_reset-password_page_actions_f3021308.js.map