module.exports=[39515,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_assets_page_actions_6a2ce0a4.js.map