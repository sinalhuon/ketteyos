module.exports=[84657,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_profile_page_actions_f43720f6.js.map