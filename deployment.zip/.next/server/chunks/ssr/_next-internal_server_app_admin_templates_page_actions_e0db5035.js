module.exports=[7578,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_templates_page_actions_e0db5035.js.map