module.exports=[41955,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_clients_admins_%5Bid%5D_edit_page_actions_762d641b.js.map