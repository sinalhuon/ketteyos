module.exports=[56615,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_new_page_actions_3e820528.js.map