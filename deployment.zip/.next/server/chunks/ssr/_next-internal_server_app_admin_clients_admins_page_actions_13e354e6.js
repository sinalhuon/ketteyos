module.exports=[5828,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_clients_admins_page_actions_13e354e6.js.map