module.exports=[8893,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_settings_logo_route_actions_8f0da6dc.js.map