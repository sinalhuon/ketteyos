module.exports=[27054,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_profile_password_route_actions_d02b58ec.js.map