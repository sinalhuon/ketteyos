var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/settings/logo/route.js")
R.c("server/chunks/[root-of-the-server]__6cdddf3f._.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_settings_logo_route_actions_8f0da6dc.js")
R.m(45295)
module.exports=R.m(45295).exports
