var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/settings/route.js")
R.c("server/chunks/[root-of-the-server]__cc138c67._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_next-internal_server_app_api_settings_route_actions_a476013b.js")
R.m(61525)
module.exports=R.m(61525).exports
