var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/profile/image/route.js")
R.c("server/chunks/[root-of-the-server]__4fa52cf6._.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_profile_image_route_actions_40c9592f.js")
R.m(78181)
module.exports=R.m(78181).exports
