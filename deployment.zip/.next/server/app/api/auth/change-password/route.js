var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/change-password/route.js")
R.c("server/chunks/[root-of-the-server]__399aa10e._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_change-password_route_actions_2c23f77f.js")
R.m(56219)
module.exports=R.m(56219).exports
