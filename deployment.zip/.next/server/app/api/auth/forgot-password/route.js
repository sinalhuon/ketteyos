var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/forgot-password/route.js")
R.c("server/chunks/[root-of-the-server]__a9ff488a._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_forgot-password_route_actions_ada86dd3.js")
R.m(69157)
module.exports=R.m(69157).exports
