var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/users/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__c24b4e6e._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_users_[id]_route_actions_b7a31f56.js")
R.m(84085)
module.exports=R.m(84085).exports
