var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/permissions/route.js")
R.c("server/chunks/[root-of-the-server]__951f0bec._.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_permissions_route_actions_6f21bcc8.js")
R.m(12922)
module.exports=R.m(12922).exports
