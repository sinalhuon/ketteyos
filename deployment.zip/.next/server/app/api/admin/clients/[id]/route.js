var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/clients/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__f7f485e8._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_clients_[id]_route_actions_ec5e82c5.js")
R.m(62490)
module.exports=R.m(62490).exports
