var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/clients/route.js")
R.c("server/chunks/[root-of-the-server]__443d7dc1._.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_clients_route_actions_04aea9e1.js")
R.m(29531)
module.exports=R.m(29531).exports
