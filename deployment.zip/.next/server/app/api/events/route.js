var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/events/route.js")
R.c("server/chunks/[root-of-the-server]__e272721f._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_next-internal_server_app_api_events_route_actions_d05c80f6.js")
R.m(50608)
module.exports=R.m(50608).exports
