var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/events/[id]/guests/import/route.js")
R.c("server/chunks/[root-of-the-server]__fecc4cd4._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_a2d28408.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_next-internal_server_app_api_events_[id]_guests_import_route_actions_17581b0e.js")
R.m(25241)
module.exports=R.m(25241).exports
